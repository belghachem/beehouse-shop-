from django.db import models
from django.contrib.auth.models import User
from products.models import Product  # Import from products app!

class Cart(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    created = models.DateTimeField(auto_now_add=True)

class CartItem(models.Model):
    cart = models.ForeignKey(Cart, on_delete=models.CASCADE, related_name='items')
    product = models.ForeignKey(Product, on_delete=models.CASCADE)  # Links to Product!
    quantity = models.IntegerField(default=1)
    added = models.DateTimeField(auto_now_add=True)
    
    def get_total_price(self):
        return self.quantity * self.product.price