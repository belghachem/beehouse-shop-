from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import UserProfile
from cart.models import Cart  # Can access cart from users app

@login_required
def profile(request):
    profile, created = UserProfile.objects.get_or_create(user=request.user)
    cart = Cart.objects.filter(user=request.user).first()
    
    return render(request, 'users/profile.html', {
        'profile': profile,
        'cart': cart
    })